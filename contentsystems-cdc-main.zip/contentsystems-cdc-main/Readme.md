# Change data capture using debezium embedded engine in a Spring Boot application
The debezium engine will capture changes on the configured source and will hand it to the Spring boot app. The app will capture the change events and extract the SQLs and execute on a configured target database

## Prerequisites
- A source and a target MySQL database.
  - Option 1: Using docker
    - Install docker on your local
    - You can follow this guide to create containers and install MySQL on bringing them up: https://developer.ibm.com/tutorials/docker-dev-db/

## Setup steps

1) Copy the MySQL connection details for the source database and set the properties prefixed with "source*" in application.properties file. Do the same thing for target database into "target*" properties
2) We will also need a database for the Spring boot application to store offset information and any application related data. You can either use the target database or create another instance of the MySQL database. Add the connection details in properties prefixed with "cdc*" in application.properties file. 
3) Set the databases that you want to do CDC for by setting it as a comma seperated value for the property "database.include.list" in DebeziumConnectorConfig. This config class has different settings to achieve CDC as desired