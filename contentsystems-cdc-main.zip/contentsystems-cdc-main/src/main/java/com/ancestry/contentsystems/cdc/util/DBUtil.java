package com.ancestry.contentsystems.cdc.util;

import java.util.HashMap;
import java.util.Map;

public class DBUtil {
    private String keyString="";
    private String valueString="";

    public static HashMap<String, Object> getQueryParameters(Map<String,Object> payload){
        HashMap<String,Object> keyToValueMap = new HashMap<>();
        payload.forEach((k,v) -> {
            keyToValueMap.put(String.valueOf(k),v);
        });
        return keyToValueMap;
    }

    public static HashMap<String, Object> getQueryParametersForUpdate(Map<String, Object> payload, Map<String, Object> keyPayload) {
        HashMap<String,Object> keyToValueMap = new HashMap<>();
        payload.forEach((k,v) -> {
            if(keyPayload.get(k)==null) {
                keyToValueMap.put(String.valueOf(k), v);
            }
        });
        return keyToValueMap;
    }
}
