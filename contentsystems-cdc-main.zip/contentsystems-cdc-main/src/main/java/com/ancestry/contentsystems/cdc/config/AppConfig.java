package com.ancestry.contentsystems.cdc.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.datasource.DriverManagerDataSource;

import javax.sql.DataSource;

@Configuration
@ComponentScan("com.ancestry.contentsystems.cdc")
public class AppConfig {

	@Value("${target.datasource.url}")
	private String targetDatasourceUrl;

	@Value("${target.datasource.username}")
	private String targetDatasourceUsername;

	@Value("${target.datasource.password}")
	private String targetDatasourcePassword;


	@Value("${cdc.datasource.url}")
	private String cdcDatasourceUrl;

	@Value("${cdc.datasource.username}")
	private String cdcDatasourceUsername;

	@Value("${cdc.datasource.password}")
	private String cdcDatasourcePassword;

	@Bean("targetDbDatasource")
	public DataSource targetDbDatasource() {
		DriverManagerDataSource driverManagerDataSource = new DriverManagerDataSource();
		driverManagerDataSource.setUrl(targetDatasourceUrl);
		driverManagerDataSource.setUsername(targetDatasourceUsername);
		driverManagerDataSource.setPassword(targetDatasourcePassword);
		driverManagerDataSource.setDriverClassName("com.mysql.cj.jdbc.Driver");
		return driverManagerDataSource;
	}

	@Bean("cdcDatasource")
	public DataSource cdcDatasource() {
		DriverManagerDataSource driverManagerDataSource = new DriverManagerDataSource();
		driverManagerDataSource.setUrl(cdcDatasourceUrl);
		driverManagerDataSource.setUsername(cdcDatasourceUsername);
		driverManagerDataSource.setPassword(cdcDatasourcePassword);
		driverManagerDataSource.setDriverClassName("com.mysql.cj.jdbc.Driver");
		return driverManagerDataSource;
	}
}