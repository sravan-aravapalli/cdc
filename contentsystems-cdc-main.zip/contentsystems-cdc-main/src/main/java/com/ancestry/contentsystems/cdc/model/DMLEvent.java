package com.ancestry.contentsystems.cdc.model;

import java.util.Map;

public class DMLEvent {

    public DMLEvent(String schemaName, String tableName, Map<String,Object> queryParametersMap, DMLEventType dmlEventType, Map<String,Object> primaryKeyMap){
        this.schemaName = schemaName;
        this.tableName = tableName;
        this.queryParametersMap = queryParametersMap;

        this.primaryKeyMap = primaryKeyMap;
        this.eventType = dmlEventType;

    }
    private String schemaName;
    private String tableName;

    public DMLEventType  eventType;

    private Map<String,Object> queryParametersMap;
    private Map<String,Object> primaryKeyMap;

    public String getSchemaName() {
        return schemaName;
    }

    public void setSchemaName(String schemaName) {
        this.schemaName = schemaName;
    }

    public String getTableName() {
        return tableName;
    }

    public void setTableName(String tableName) {
        this.tableName = tableName;
    }

    public Map<String, Object> getPrimaryKeyMap() {
        return primaryKeyMap;
    }

    public void setPrimaryKeyMap(Map<String, Object> primaryKeyMap) {
        this.primaryKeyMap = primaryKeyMap;
    }

    public Map<String, Object> getQueryParametersMap() {
        return queryParametersMap;
    }

    public void setQueryParametersMap(Map<String, Object> queryParametersMap) {
        this.queryParametersMap = queryParametersMap;
    }
}
