package com.ancestry.contentsystems.cdc.util;

import com.ancestry.contentsystems.cdc.model.Offset;
import org.apache.kafka.connect.errors.ConnectException;
import org.apache.kafka.connect.runtime.WorkerConfig;
import org.apache.kafka.connect.storage.MemoryOffsetBackingStore;
import org.apache.kafka.connect.util.SafeObjectInputStream;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.stereotype.Component;

import javax.sql.DataSource;
import java.io.EOFException;
import java.io.File;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.NoSuchFileException;
import java.sql.Timestamp;
import java.util.*;

@Component
public class CustomFileOffsetBackingStore extends MemoryOffsetBackingStore {
    private static final Logger log = LoggerFactory.getLogger(org.apache.kafka.connect.storage.FileOffsetBackingStore.class);
    private File file;

    private JdbcTemplate jdbcTemplate;

    @Value("${cdc.datasource.url}")
    private String cdcDatasourceUrl;

    @Value("${cdc.datasource.username}")
    private String cdcDatasourceUsername;

    @Value("${cdc.datasource.password}")
    private String cdcDatasourcePassword;

    @Autowired
    public CustomFileOffsetBackingStore() {
    }

    public void configure(WorkerConfig config) {
        super.configure(config);
    }

public synchronized void start() {
        super.start();
        this.load();
    }

    public synchronized void stop() {
        super.stop();
        log.info("Stopped FileOffsetBackingStore");
    }

    private void load() {
        try {
            try {
                this.data = new HashMap();

                Optional<Offset> offset = getOffset();
                if(offset.isPresent())
                    this.data.put(ByteBuffer.wrap(offset.get().getOffsetKey().getBytes(StandardCharsets.UTF_8)),
                            ByteBuffer.wrap(offset.get().getOffsetKey().getBytes(StandardCharsets.UTF_8)));
            } catch (Throwable var18) {
                throw var18;
            }
        } catch (Exception ex) {
            throw ex;
        }
    }

    protected void save() {
            try {
                Map<byte[], byte[]> raw = new HashMap();
                Iterator var4 = this.data.entrySet().iterator();
                byte[] key = new byte[1];
                byte[] value =new byte[1];

                while(var4.hasNext()) {
                    Map.Entry<ByteBuffer, ByteBuffer> mapEntry = (Map.Entry)var4.next();
                    key = mapEntry.getKey() != null ? ((ByteBuffer)mapEntry.getKey()).array() : null;
                    value = mapEntry.getValue() != null ? ((ByteBuffer)mapEntry.getValue()).array() : null;
                }
                updateOffsetStorageDb(key,value);
            } catch (Throwable var16) {
                throw var16;
            }
    }

    private void updateOffsetStorageDb(byte[] key, byte[] value) {

        this.jdbcTemplate = new JdbcTemplate(cdcDatasource());
        String keyString = new String(key, StandardCharsets.UTF_8);
        String valueString = new String(value, StandardCharsets.UTF_8);

        String sql = "INSERT INTO offset_storage (offset_key, offset_value, created_date) VALUES (?, ?, ?)";

        int result = jdbcTemplate.update(sql, keyString, valueString, new Timestamp(new Date().getTime()));
    }

    public DataSource cdcDatasource() {
        DriverManagerDataSource driverManagerDataSource = new DriverManagerDataSource();
        driverManagerDataSource.setUrl("jdbc:mysql://localhost:3306/cdc");
        driverManagerDataSource.setUsername("root");
        driverManagerDataSource.setPassword("ancestry");
        driverManagerDataSource.setDriverClassName("com.mysql.cj.jdbc.Driver");
        return driverManagerDataSource;
    }

    private Optional<Offset> getOffset(){

        this.jdbcTemplate = new JdbcTemplate(cdcDatasource());
        String query = "select * from cdc.offset_storage order by id desc limit 1";
        Offset offset;
        try {
            offset = jdbcTemplate.queryForObject(
                    query, new Offset());
        }catch (EmptyResultDataAccessException e) {
                log.warn("No offset record found in the database ", e);
                return Optional.empty();
        }
        return Optional.of(offset);
    }
}

