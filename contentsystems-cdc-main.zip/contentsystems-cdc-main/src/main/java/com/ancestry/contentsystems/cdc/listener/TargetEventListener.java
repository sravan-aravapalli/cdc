package com.ancestry.contentsystems.cdc.listener;

import com.ancestry.contentsystems.cdc.model.DDLEvent;
import com.ancestry.contentsystems.cdc.model.DMLEvent;
import com.ancestry.contentsystems.cdc.repository.TargetRepositoryImpl;
import com.ancestry.contentsystems.cdc.util.DBUtil;
import net.sf.jsqlparser.JSQLParserException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.event.EventListener;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;

import java.util.Map;

@Component
public class TargetEventListener {
    private Logger logger = LoggerFactory.getLogger(TargetEventListener.class);

    @Autowired
    private TargetRepositoryImpl cdcRepository;


    @Async
    @EventListener
    public void consumeDMLEvent(DMLEvent dmlEvent){
        Map<String,Object> queryParameterMap = DBUtil.getQueryParameters(dmlEvent.getQueryParametersMap());

        switch(dmlEvent.eventType) {
            case INSERT:
                cdcRepository.insert(dmlEvent, queryParameterMap);
                break;
            case CREATE:
                cdcRepository.insert(dmlEvent, queryParameterMap);
                break;
            case READ:
                cdcRepository.insert(dmlEvent, queryParameterMap);
                break;
            case DELETE:
                cdcRepository.delete(dmlEvent,queryParameterMap);
                break;
            case UPDATE:
                cdcRepository.update(dmlEvent, DBUtil.getQueryParametersForUpdate(dmlEvent.getQueryParametersMap(), dmlEvent.getPrimaryKeyMap()));
                break;
            default:
                break;
        }
    }

    @Async
    @EventListener
    public void consumeDDLEvent(DDLEvent ddlEvent) throws JSQLParserException {
        logger.debug(ddlEvent.getDdl());
        cdcRepository.create(ddlEvent);
    }


}
