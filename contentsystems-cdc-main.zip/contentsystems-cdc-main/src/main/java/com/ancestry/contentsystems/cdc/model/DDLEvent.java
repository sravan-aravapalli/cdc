package com.ancestry.contentsystems.cdc.model;

public class DDLEvent {

    public DDLEvent(String ddl, String databaseName){
        this.ddl = ddl;
        this.databaseName = databaseName;
    }

    private String ddl;

    private String databaseName;

    public String getDdl() {
        return ddl;
    }

    public void setDdl(String ddl) {
        this.ddl = ddl;
    }

    public String getDatabaseName() {
        return databaseName;
    }

    public void setDatabaseName(String databaseName) {
        this.databaseName = databaseName;
    }
}
