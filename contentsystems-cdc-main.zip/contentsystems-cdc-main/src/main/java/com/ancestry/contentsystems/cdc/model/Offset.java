package com.ancestry.contentsystems.cdc.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;

public class Offset implements RowMapper<Offset> {
    @JsonProperty("offset_value")
    private String offsetKey;

    @JsonProperty("offset_key")
    private String offsetValue;

    private Timestamp createdDate;

    public Timestamp getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Timestamp createdDate) {
        this.createdDate = createdDate;
    }

    public String getOffsetKey() {
        return offsetKey;
    }

    public void setOffsetKey(String offsetKey) {
        this.offsetKey = offsetKey;
    }

    public String getOffsetValue() {
        return offsetValue;
    }

    public void setOffsetValue(String offsetValue) {
        this.offsetValue = offsetValue;
    }

    @Override
    public Offset mapRow(ResultSet rs, int rowNum) throws SQLException {
        Offset offset = new Offset();

        offset.setOffsetKey(rs.getString("offset_key"));
        offset.setOffsetValue(rs.getString("offset_value"));


        return offset;
    }
}
