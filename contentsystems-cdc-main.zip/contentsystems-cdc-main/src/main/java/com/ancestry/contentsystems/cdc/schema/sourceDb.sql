create database dictionary;

CREATE TABLE dictionary.state
(id INT AUTO_INCREMENT PRIMARY KEY,
 name VARCHAR(5000),
 description VARCHAR(5000));

INSERT INTO dictionary.state(name,description) VALUES ('MT','Montana');

INSERT INTO dictionary.state(name,description) VALUES ('DC','Washington DC');

use dictionary;
update state set description='Massachusetts3' where id=1;