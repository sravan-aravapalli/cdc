package com.ancestry.contentsystems.cdc.publisher;

import com.ancestry.contentsystems.cdc.model.DDLEvent;
import com.ancestry.contentsystems.cdc.model.DMLEvent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.stereotype.Component;

@Component
public class SourceEventPublisher {

    private Logger logger = LoggerFactory.getLogger(SourceEventPublisher.class);
    @Autowired
    private ApplicationEventPublisher applicationEventPublisher;

    public void publishDDLEvent(DDLEvent ddlEvent){
        applicationEventPublisher.publishEvent(ddlEvent);
    }

    public void publishDMLEvent(DMLEvent dmlEvent) {
        applicationEventPublisher.publishEvent(dmlEvent);
    }
}
