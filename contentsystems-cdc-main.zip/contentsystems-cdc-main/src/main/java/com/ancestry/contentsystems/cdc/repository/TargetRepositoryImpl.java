package com.ancestry.contentsystems.cdc.repository;

import com.ancestry.contentsystems.cdc.listener.TargetEventListener;
import com.ancestry.contentsystems.cdc.model.DDLEvent;
import com.ancestry.contentsystems.cdc.model.DMLEvent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import javax.sql.DataSource;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Repository
public class TargetRepositoryImpl {
    @Autowired
    public TargetRepositoryImpl(@Qualifier("targetDbDatasource") DataSource targetDbDatasource){
        jdbcTemplate = new JdbcTemplate(targetDbDatasource);
    }

    private JdbcTemplate jdbcTemplate;
    private Logger logger = LoggerFactory.getLogger(TargetEventListener.class);
    private String columns ="";
    private List<Object> bindVariables;
    private String query ="";
    private String querySuffix ="";

    public void insert(DMLEvent dmlEvent, Map<String,Object> queryParameterMap){
        columns="";
        bindVariables = new ArrayList<>();
        queryParameterMap.forEach((k,v)-> {
            columns+=(k+",");
            bindVariables.add(v);
        });

        String parameterValuesList = "?,".repeat(bindVariables.size());

        String parameterizedQuery = "INSERT INTO "+
                dmlEvent.getSchemaName()+"."+dmlEvent.getTableName()+"("+
                columns.replaceAll(",$", "")+") "
                +"VALUES ("
                + parameterValuesList.replaceAll(",$", "")
                +")";
        int result = jdbcTemplate.update(parameterizedQuery,bindVariables.toArray());
    }

    public void delete(DMLEvent dmlEvent, Map<String,Object> queryParameterMap){
        query ="";
        querySuffix ="";
        dmlEvent.getPrimaryKeyMap().forEach((k,v)->{
            querySuffix+=String.valueOf(k)+"="+v+",";
        });
        String parameterizedQuery = "delete from "+
                dmlEvent.getSchemaName()+"."+dmlEvent.getTableName()
                +" WHERE " + querySuffix.replaceAll(",$", "")
                ;

        int result = jdbcTemplate.update(parameterizedQuery);
    }

    public void update(DMLEvent dmlEvent, Map<String,Object> queryParameterMap){
        bindVariables = new ArrayList<>();
        query ="";
        querySuffix ="";
        queryParameterMap.forEach((k,v)->{
            query+=String.valueOf(k)+"=?,";
            bindVariables.add(v);
        });
        dmlEvent.getPrimaryKeyMap().forEach((k,v)->{
            querySuffix+=String.valueOf(k)+"="+v+",";
        });
        String parameterizedQuery = "UPDATE "+
                dmlEvent.getSchemaName()+"."+dmlEvent.getTableName()+" SET "
                + query.replaceAll(",$", "")
                +" WHERE " + querySuffix.replaceAll(",$", "")
                ;

        int result = jdbcTemplate.update(parameterizedQuery,bindVariables.toArray());
    }

    public void create(DDLEvent ddlEvent) {
        logger.debug(ddlEvent.getDdl());

        String sql="";
        try {
            if (ddlEvent.getDatabaseName() != null && !ddlEvent.getDatabaseName().isEmpty()) {
                sql = "USE " + ddlEvent.getDatabaseName() + ";"+ddlEvent.getDdl()+";";
                jdbcTemplate.execute(sql);
                return;
            }else{
                sql = ddlEvent.getDdl()+";";
            }
        }catch(Exception ex){
            ex.printStackTrace();
            logger.error("Exception while executing DDL on target DB as the schema %s doesn't exist", ddlEvent.getDatabaseName());
            sql = ddlEvent.getDdl()+";";
        }
        jdbcTemplate.execute(sql);
    }
}
