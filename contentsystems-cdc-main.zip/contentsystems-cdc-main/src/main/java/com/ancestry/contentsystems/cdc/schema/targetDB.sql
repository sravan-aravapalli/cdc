create database dictionary;

CREATE TABLE dictionary.state
(id INT AUTO_INCREMENT PRIMARY KEY,
 name VARCHAR(5000),
 description VARCHAR(5000));