package com.ancestry.contentsystems.cdc.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.io.File;
import java.io.IOException;

@Configuration
public class DebeziumConnectorConfig {

    /**
     * Database details.
     */
    @Value("${master.datasource.host}")
    private String masterDbHost;

    @Value("${master.datasource.database}")
    private String masterDbName;

    @Value("${master.datasource.port}")
    private String masterDbPort;

    @Value("${master.datasource.username}")
    private String masterDbUsername;

    @Value("${master.datasource.password}")
    private String masterDbPassword;

    @Bean
    public io.debezium.config.Configuration debeziumConnector() throws IOException {
        File offsetStorageFile = new File("offsets.dat");
        offsetStorageFile.createNewFile();
        File dbHistoryFile = new File("dbhistory.dat");
        dbHistoryFile.createNewFile();
        File schemaHistoryFile = new File("schemahistory.dat");
        schemaHistoryFile.createNewFile();
        return io.debezium.config.Configuration.create()
                .with("name", "my-sql-connector")
                .with("connector.class", "io.debezium.connector.mysql.MySqlConnector")
                /*Custom offset backing store class. Will read and write offsets to database instead of file*/
                .with("offset.storage","org.apache.kafka.connect.storage.FileOffsetBackingStore")
                //.with("offset.storage","com.ancestry.contentsystems.cdc.util.CustomFileOffsetBackingStore")
                .with("offset.storage.file.filename", offsetStorageFile.getAbsolutePath())
                //.with("time.precision.mode", "adaptive_time_microseconds")
                .with("time.precision.mode", "connect")
                .with("offset.flush.interval.ms", 5000)
                .with("database.hostname", masterDbHost)
                .with("database.port", masterDbPort)
                .with("database.user", masterDbUsername)
                .with("database.password", masterDbPassword)
                .with("database.allowPublicKeyRetrieval","true")
                /*database.dbname can be used to only capture change events from a specific database on the host*/
                //.with("database.dbname", masterDbName)
                /*database.include.list can be used to specify the database list to be included for CDC*/
                //.with("database.include.list","dictionary,employees")
                .with("database.include.list","dictionary")
                /*table.exclude.list can be used to specify the table list to be included for CDC*/
                //.with("table.exclude.list","dictionary.employees")
                .with("topic.prefix", "dictionary-db")
                /*include.schema.changes can be used to exclude schema change events to be captured*/
                //.with("include.schema.changes", "false")
                .with("database.server.id", 2)
                .with("snapshot.mode","schema_only")
                //.with("snapshot.include.collection.list","dictionary,employees")
                .with("database.connectionTimeZone", "America/New_York")
                .with("server.id", 85744)
                .with("server.name", "dictionary-db1")
                .with("schema.history.internal", "io.debezium.storage.file.history.FileSchemaHistory")
                .with("schema.history.internal.file.filename", schemaHistoryFile)
                .build();
    }
}
