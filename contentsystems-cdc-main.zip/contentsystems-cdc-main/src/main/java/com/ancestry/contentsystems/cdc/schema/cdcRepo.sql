create database cdc;

CREATE TABLE cdc.offset_storage
(id INT AUTO_INCREMENT PRIMARY KEY,
 offset_key VARCHAR(5000),
 offset_value VARCHAR(5000),
 created_date TIMESTAMP
 );

drop table cdc.offset_storage;

delete from cdc.offset_storage;







