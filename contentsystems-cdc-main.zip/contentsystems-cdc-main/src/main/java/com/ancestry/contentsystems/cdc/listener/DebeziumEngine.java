package com.ancestry.contentsystems.cdc.listener;

import com.ancestry.contentsystems.cdc.model.DMLEvent;
import com.ancestry.contentsystems.cdc.model.DMLEventType;
import com.ancestry.contentsystems.cdc.publisher.SourceEventPublisher;
import io.debezium.config.Configuration;
import io.debezium.data.Envelope;
import io.debezium.embedded.Connect;
import io.debezium.engine.RecordChangeEvent;
import io.debezium.engine.format.ChangeEventFormat;
import org.apache.commons.lang3.tuple.Pair;
import org.apache.kafka.connect.data.Field;
import org.apache.kafka.connect.data.Struct;
import org.apache.kafka.connect.source.SourceRecord;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import java.io.IOException;
import java.util.Map;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

import static io.debezium.data.Envelope.FieldName.*;
import static java.util.stream.Collectors.toMap;

@Component
public class DebeziumEngine {

    public Logger logger = LoggerFactory.getLogger(DebeziumEngine.class);

    @Autowired
    private SourceEventPublisher sourceEventPublisher;

    private final io.debezium.engine.DebeziumEngine<RecordChangeEvent<SourceRecord>> debeziumEngine;
    public DebeziumEngine(Configuration connectorConfiguration) {

        this.debeziumEngine = io.debezium.engine.DebeziumEngine.create(ChangeEventFormat.of(Connect.class))
                .using(connectorConfiguration.asProperties())
                .notifying((records, committer) -> {
                    for (RecordChangeEvent<SourceRecord> r : records) {
                        handleChangeEvent(r,committer);
                        committer.markProcessed(r);
                    }
                    committer.markBatchFinished();
                }).build();
    }

    private final Executor executor = Executors.newSingleThreadExecutor();

    @PostConstruct
    private void start() {
        this.executor.execute(debeziumEngine);
    }

    @PreDestroy
    private void stop() throws IOException {
        if (this.debeziumEngine != null) {
            this.debeziumEngine.close();
        }
    }


    private void handleChangeEvent(RecordChangeEvent<SourceRecord> sourceRecordRecordChangeEvent, io.debezium.engine.DebeziumEngine.RecordCommitter<RecordChangeEvent<SourceRecord>> committer) {
        logger.debug("Parsing the latest change event record!");
        try {
            logger.debug("sourceRecordRecordChangeEvent:" + sourceRecordRecordChangeEvent.toString());

            SourceRecord sourceRecord = sourceRecordRecordChangeEvent.record();
            Struct sourceRecordChangeValue = (Struct) sourceRecord.value();
            boolean isDDL;
            try {
                isDDL = ((Struct) sourceRecord.value()).get("ddl") != null;
            } catch (org.apache.kafka.connect.errors.DataException | NullPointerException ex) {
                logger.debug("Change event is not a DDL. Catching the exception and setting isDDL to false to proceed handling the event!");
                isDDL = false;
            }
            /*Event handling logic for DMLs*/
            if (!isDDL) {
                logger.debug("handleChangeEvent method found the change event to be a DML!");
                if (sourceRecordChangeValue != null) {
                    Envelope.Operation operation = Envelope.Operation.forCode((String) sourceRecordChangeValue.get(OPERATION));

                    String record = operation == Envelope.Operation.DELETE ? BEFORE : AFTER;
                    Map<String, Object> primaryKeyMap =null;
                    Struct recordStruct = (Struct) sourceRecordChangeValue.get(record);
                    Map<String, Object> queryParameterMap = recordStruct.schema().fields().stream()
                            .map(Field::name)
                            .filter(fieldName -> recordStruct.get(fieldName) != null)
                            .map(fieldName -> Pair.of(fieldName, recordStruct.get(fieldName)))
                            .collect(toMap(Pair::getKey, Pair::getValue));

                    if(operation == Envelope.Operation.UPDATE || operation == Envelope.Operation.DELETE) {
                        Struct sourceRecordChangeKey = (Struct) sourceRecord.key();
                        primaryKeyMap = sourceRecordChangeKey.schema().fields().stream().map(Field::name)
                                .filter(fieldName -> sourceRecordChangeKey.get(fieldName) != null)
                                .map(fieldName -> Pair.of(fieldName, sourceRecordChangeKey.get(fieldName)))
                                .collect(toMap(Pair::getKey, Pair::getValue));
                    }

                    Struct sourceStruct = (Struct) sourceRecordChangeValue.get(SOURCE);
                    Map<String, Object> metadata = sourceStruct.schema().fields().stream()
                            .map(Field::name)
                            .filter(fieldName -> sourceStruct.get(fieldName) != null
                                    && ("table".equals(fieldName) || "db".equals(fieldName)))
                            .map(fieldName -> Pair.of(fieldName, sourceStruct.get(fieldName)))
                            .collect(toMap(Pair::getKey, Pair::getValue));
                    logger.debug(metadata.toString());
                    try {
                        String tableName = (String) metadata.get("table");
                        sourceEventPublisher.publishDMLEvent(new DMLEvent((String) metadata.get("db"),
                            tableName,
                                queryParameterMap,
                                 DMLEventType.valueOf(operation.name()),primaryKeyMap));
                    }catch(Exception ex){
                        ex.printStackTrace();
                        logger.error("Unable to parse DML change event!!");
                        throw ex;
                    }

                }
            }
            /* Logic to handle DDL. Going to exclude from Phase 1
            else {
                logger.debug("handleChangeEvent method found the change event to be a DDL!");
                Object ddlStatement = ((Struct) sourceRecord.value()).get("ddl");
                Object databaseName = ((Struct) sourceRecord.value()).get("databaseName");
                try{
                    sourceEventPublisher.publishDDLEvent(new DDLEvent(String.valueOf(ddlStatement),String.valueOf(databaseName)));
                } catch(Exception ex){
                    logger.error("There was an exception while parsing ddl statement");
                    ex.printStackTrace();
                    //throw ex;
                }

            }*/
        } catch(Exception ex){
            logger.error("Exception while processing change event");
            ex.printStackTrace();
            throw ex;
        }

    }
}
