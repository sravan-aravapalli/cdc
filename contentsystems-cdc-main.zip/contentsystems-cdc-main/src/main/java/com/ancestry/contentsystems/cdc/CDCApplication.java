package com.ancestry.contentsystems.cdc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CDCApplication {
    public static void main(String[] args) {
        SpringApplication.run(CDCApplication.class, args);
    }
}
