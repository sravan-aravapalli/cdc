package com.ancestry.contentsystems.cdc.model;

public enum DMLEventType {
    INSERT,UPDATE,DELETE,READ,CREATE
}
